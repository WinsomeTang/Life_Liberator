﻿




using Life_LiberatorApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
namespace Life_LiberatorApi.Controllers

{
    [ApiController]
    [Route("api/[controller]")]
    public class ProjectsController : ControllerBase
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public ProjectsController(IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult GetAllProjects()
        {
           // try { 
            var mvcApiBaseUrl = _configuration["MvcApiBaseUrl"];
            //var httpClient = _httpClientFactory.CreateClient();
            using var httpClient = _httpClientFactory.CreateClient();
            httpClient.BaseAddress = new Uri(mvcApiBaseUrl);

            var response = httpClient.GetAsync($"{mvcApiBaseUrl}/api/Projects").Result;

            //Console.WriteLine($"Request URL: {httpClient.BaseAddress}/api/Projects");

            if (response.IsSuccessStatusCode)
            {
                var projectsJson = response.Content.ReadAsStringAsync().Result;
                return Ok(projectsJson);
            }
            else
            {
                  //  Console.WriteLine($"Error in GetAllProjects action: {response.StatusCode}");
                    return StatusCode((int)response.StatusCode);
            }
      //  }
    //        catch (Exception ex)
    //{
    //            Console.WriteLine($"Error in GetAllProjects action: {ex.Message}");
    //            throw;  // Rethrow the exception for debugging purposes
    //        }
        }

        [HttpGet("{id}")]
        public IActionResult GetProjectById(int id)
        {
            var mvcApiBaseUrl = _configuration["MvcApiBaseUrl"];
            var httpClient = _httpClientFactory.CreateClient();

            var response = httpClient.GetAsync($"{mvcApiBaseUrl}/api/Projects/{id}").Result;

            if (response.IsSuccessStatusCode)
            {
                var projectJson = response.Content.ReadAsStringAsync().Result;
                return Ok(projectJson);
            }
            else
            {
                return StatusCode((int)response.StatusCode);
            }
        }

        [HttpPost]
        public IActionResult CreateProject([FromBody] Project project) 
        {
            var mvcApiBaseUrl = _configuration["MvcApiBaseUrl"];
            var httpClient = _httpClientFactory.CreateClient();

            var response = httpClient.PostAsJsonAsync($"{mvcApiBaseUrl}/api/Projects", project).Result;

            if (response.IsSuccessStatusCode)
            {
                var createdProjectJson = response.Content.ReadAsStringAsync().Result;
                return Ok(createdProjectJson);
            }
            else
            {
                return StatusCode((int)response.StatusCode);
            }
        }
    }
}
