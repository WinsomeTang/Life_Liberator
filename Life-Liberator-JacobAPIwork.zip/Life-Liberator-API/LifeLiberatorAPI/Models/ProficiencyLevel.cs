﻿using System;
namespace Life_LiberatorApi.Models
{
    public enum ProficiencyLevel
    {
        Beginner,
        Intermediate,
        Advanced,
        // Add other proficiency levels as needed
    }
}

