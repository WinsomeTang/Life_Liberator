﻿using Life_Liberator.Data;
using Life_Liberator.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;

namespace Life_Liberator.Controllers;

public class HomeController : Controller
{
    //private readonly AppDbContext _appDbContext;
    //public HomeController(AppDbContext appDbContext)
    //{
    //    _appDbContext = appDbContext;
    //}

    private readonly AppDbContext _appDbContext;
    private readonly IConfiguration _configuration;
    private readonly IHttpClientFactory _httpClientFactory;
    // Get the Web Api URI
    Uri baseAddress = new Uri("https://localhost:5264");
    // Create a HTTP client for the Web Api
    private HttpClient _client;
    public HomeController(AppDbContext appDbContext, IConfiguration configuration, IHttpClientFactory httpClientFactory)
    {
        _appDbContext = appDbContext;
        _configuration = configuration;
        _httpClientFactory = httpClientFactory;
      
  
        _client = new HttpClient();
        // Add the base address to the client
        _client.BaseAddress = baseAddress;
   
}

    //public IActionResult Index()
    //{
    //    return View();
    //}

    //use web api to get all the projects
    public IActionResult Index()
    {
        // try
        // { 
        var baseUri = _client.BaseAddress;  //new Uri(_configuration["WebApiBaseUrl"]);
        //var projectsApiUrl = new Uri(baseUri, "/api/Projects").ToString();
        var projectsApiUrl = "http://localhost:5264/api/Projects";
       // Console.WriteLine($"Request URL: {projectsApiUrl}");
        var httpClient = _httpClientFactory.CreateClient();
        var projectsJson = httpClient.GetStringAsync(projectsApiUrl).Result;
        var projects = JsonConvert.DeserializeObject<IEnumerable<Project>>(projectsJson);

        return View(projects);
    //}
    //    catch (Exception ex)
    //    {
    //        Console.WriteLine($"Error in Index action: {ex.Message}");
    //        throw;  // Rethrow the exception for debugging purposes
    //    }
    }

    public IActionResult SignUp()
    {
        return View();
    }

    public IActionResult Dashboard()
    {
        return View();
    }

    //[HttpPost]
    //[ValidateAntiForgeryToken]
    //public IActionResult SignUp(User user)
    //{
    //    if (ModelState.IsValid)
    //    {
    //        // Save user to the database
    //        _appDbContext.Users.Add(user);
    //        _appDbContext.SaveChanges();

    //        // Redirect to the login page or another appropriate page
    //        return RedirectToAction("ScheduleForm", new { id = user.UserId });
    //    }

    //    // If ModelState is not valid, return to the signup page with validation errors
    //    return View(user);
    //}

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult SignUp(User user)
    {
        if (ModelState.IsValid)
        {
            // Send the user data to the Web API to create a user
            var createApiUrl = $"{_configuration["WebApiBaseUrl"]}/api/Users";
            var httpClient = _httpClientFactory.CreateClient();
            var response = httpClient.PostAsJsonAsync(createApiUrl, user).Result;

            if (response.IsSuccessStatusCode)
            {
                // Redirect to the login page or another appropriate page
                return RedirectToAction("ScheduleForm", new { id = user.UserId });
            }
            else
            {
                return StatusCode((int)response.StatusCode);
            }
        }

        // If ModelState is not valid, return to the signup page with validation errors
        return View(user);
    }

    //public IActionResult ScheduleForm(int id)
    //{
    //    // Retrieve the user based on the provided userId
    //    User user = _appDbContext.Users.Include(u => u.Schedules).FirstOrDefault(u => u.UserId == id);

    //    if (user == null)
    //    {
    //        // Handle the case where the user is not found
    //        return RedirectToAction("SignUp");
    //    }

    //    return View(user.Schedules);
    //}

    public IActionResult ScheduleForm(int id)
    {
        // Retrieve the user's schedules from the Web API
        var schedulesApiUrl = $"{_configuration["WebApiBaseUrl"]}/api/Users/{id}/Schedules";
        var httpClient = _httpClientFactory.CreateClient();
        var schedulesJson = httpClient.GetStringAsync(schedulesApiUrl).Result;
        var schedules = JsonConvert.DeserializeObject<IEnumerable<Schedule>>(schedulesJson);

        if (schedules == null)
        {
            // Handle the case where the schedules are not found
            return RedirectToAction("SignUp");
        }

        return View(schedules);
    }
    public IActionResult SignIn()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }



    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

