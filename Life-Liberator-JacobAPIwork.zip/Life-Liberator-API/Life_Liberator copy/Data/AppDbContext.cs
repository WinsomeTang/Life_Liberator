﻿using System;
using Microsoft.EntityFrameworkCore;
using Life_Liberator.Models;
using Microsoft.Extensions.Configuration;

namespace Life_Liberator.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Schedule> Schedules { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Define the relationship between User and Schedule
            modelBuilder.Entity<Schedule>()
                .HasOne(s => s.user)
                .WithMany(u => u.Schedules)
                .HasForeignKey(s => s.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
