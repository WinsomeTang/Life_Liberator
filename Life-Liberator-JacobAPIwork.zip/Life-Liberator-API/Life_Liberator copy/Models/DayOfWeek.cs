﻿using System;
namespace Life_Liberator.Models
{
	public enum DayOfWeek
	{
		Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
	}
}

