﻿using System;
namespace Life_Liberator.Models
{
    public enum ProficiencyLevel
    {
        Beginner,
        Intermediate,
        Advanced,
        // Add other proficiency levels as needed
    }
}

